package org.example;

import org.example.DIAnnotations.Component;
import org.example.DIAnnotations.Inject;

import java.io.*;
import java.lang.reflect.Field;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

public class BeanFactory {
    private static List<Object> components = new ArrayList<>();

    public static void init(String basePackage) {
        // Scan the base package for classes with @Component annotation
        // Create instances of those classes and inject dependencies where needed
        try {
            List<Class<?>> componentClasses = scanComponents(basePackage);

            for (Class<?> componentClass : componentClasses) {
                Object componentInstance = componentClass.getDeclaredConstructor().newInstance();
                injectDependencies(componentInstance);
                components.add(componentInstance);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static <T> T getBean(Class<T> beanClass) {
        return components.stream()
                .filter(beanClass::isInstance)
                .map(beanClass::cast)
                .findFirst()
                .orElse(null);
    }

    private static void injectDependencies(Object component) {
        Field[] fields = component.getClass().getDeclaredFields();

        for (Field field : fields) {
            if (field.isAnnotationPresent(Inject.class)) {
                field.setAccessible(true);
                Class<?> fieldType = field.getType();
                Object dependency = getBean(fieldType);
                try {
                    field.set(component, dependency);
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private static List<Class<?>> scanComponents(String basePackage) throws IOException, ClassNotFoundException {
        List<Class<?>> componentClasses = new ArrayList<>();
        String packagePath = basePackage.replace(".", "/");

        ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
        URL packageUrl = classLoader.getResource(packagePath);

        if (packageUrl != null && packageUrl.getProtocol().equals("file")) {
            File packageDir = new File(packageUrl.getFile());
            if (packageDir.isDirectory()) {
                String[] classNames = packageDir.list();
                for (String className : classNames) {
                    if (className.endsWith(".class")) {
                        String fullClassName = basePackage + "." + className.substring(0, className.length() - 6);
                        Class<?> clazz = Class.forName(fullClassName);
                        if (clazz.isAnnotationPresent(Component.class)) {
                            componentClasses.add(clazz);
                        }
                    }
                }
            }
        }

        return componentClasses;
    }


}

