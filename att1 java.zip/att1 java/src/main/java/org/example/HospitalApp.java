package org.example;

import org.example.Services.DepartmentService;
import org.example.Services.PatientService;
import org.example.models.Department;
import org.example.models.Patient;

import java.util.List;
import java.util.Scanner;

public class HospitalApp {

    public static void main(String[] args) {
        // Initialize the DI container
        BeanFactory.init("org.example.Services");



        DepartmentService departmentService = BeanFactory.getBean(DepartmentService.class);
        PatientService patientService = BeanFactory.getBean(PatientService.class);
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("Hospital Management System Menu:");
            System.out.println("1. Add Department");
            System.out.println("2. Add Patient");
            System.out.println("3. Remove Department");
            System.out.println("4. Remove Patient");
            System.out.println("5. Edit Department");
            System.out.println("6. Edit Patient");
            System.out.println("7. Display Department Information");
            System.out.println("8. Display Patient Information");
            System.out.println("0. Exit");

            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    // Add Department
                    System.out.print("Enter the department name: ");
                    String departmentName = scanner.next();
                    Department newDepartment = departmentService.createDepartment(departmentName);
                    System.out.println("Department added: " + newDepartment.getName());
                    break;

                case 3:
                    // Delete Department
                    System.out.print("Enter the department name to delete: ");
                    String departmentNameToDelete = scanner.next();
                    Department departmentToDelete = departmentService.getDepartmentByName(departmentNameToDelete);

                    if (departmentToDelete != null) {
                        departmentService.deleteDepartment(departmentToDelete);
                        System.out.println("Department deleted: " + departmentNameToDelete);
                    } else {
                        System.out.println("Department not found.");
                    }
                    break;
                case 5:
                    // Update Department
                    System.out.print("Enter the department name to update: ");
                    String departmentNameToUpdate = scanner.next();
                    Department departmentToUpdate = departmentService.getDepartmentByName(departmentNameToUpdate);

                    if (departmentToUpdate != null) {
                        System.out.print("Enter the new department name: ");
                        String newDepartmentName = scanner.next();
                        departmentService.updateDepartment(departmentToUpdate, newDepartmentName);
                        System.out.println("Department updated: " + newDepartmentName);
                    } else {
                        System.out.println("Department not found.");
                    }
                    break;

                case 7:
                    // Display Department Information
                    List<Department> departments = departmentService.getAllDepartments();
                    if (!departments.isEmpty()) {
                        System.out.println("List of Departments:");
                        for (Department department : departments) {
                            System.out.println("Department Name: " + department.getName());
                            System.out.println("Number of Patients: " + department.getNumberOfPatients());
                            System.out.println();
                        }
                    } else {
                        System.out.println("No departments found.");
                    }
                    break;

                case 2:
                    // Add Patient
                    System.out.print("Enter the patient's full name: ");
                    String patientName = scanner.next();
                    System.out.print("Enter the patient's age: ");
                    int patientAge = scanner.nextInt();
                    System.out.print("Enter the patient's gender: ");
                    String patientGender = scanner.next();

                    // Prompt user to choose a department for the patient
                    System.out.println("Available Departments:");
                    List<Department> a = departmentService.getAllDepartments();
                    for (int i = 0; i < a.size(); i++) {
                        System.out.println((i + 1) + ". " + a.get(i).getName());
                    }
                    System.out.print("Select the department for the patient: ");
                    int departmentChoice = scanner.nextInt();

                    if (departmentChoice >= 1 && departmentChoice <= a.size()) {
                        Department selectedDepartment = a.get(departmentChoice - 1);
                        Patient newPatient = patientService.createPatient(patientName, patientAge, patientGender, selectedDepartment);
                        System.out.println("Patient added: " + newPatient.getFullName());
                    } else {
                        System.out.println("Invalid department choice.");
                    }
                    break;

                case 4:
                    // Delete Patient
                    System.out.print("Enter the patient's full name to delete: ");
                    String patientNameToDelete = scanner.next();
                    Patient patientToDelete = patientService.findPatientByName(patientNameToDelete);

                    if (patientToDelete != null) {
                        patientService.deletePatient(patientToDelete);
                        System.out.println("Patient deleted: " + patientNameToDelete);
                    } else {
                        System.out.println("Patient not found.");
                    }
                    break;

                case 6:
                    // Update Patient
                    System.out.print("Enter the patient's full name to update: ");
                    String patientNameToUpdate = scanner.next();
                    Patient patientToUpdate = patientService.findPatientByName(patientNameToUpdate);

                    if (patientToUpdate != null) {
                        System.out.print("Enter the new full name: ");
                        String newFullName = scanner.next();
                        System.out.print("Enter the new age: ");
                        int newAge = scanner.nextInt();
                        System.out.print("Enter the new gender: ");
                        String newGender = scanner.next();
                        patientService.updatePatient(patientToUpdate, newFullName, newAge, newGender);
                        System.out.println("Patient updated: " + newFullName);
                    } else {
                        System.out.println("Patient not found.");
                    }
                    break;
                case 8:
                    // Display Patients by Department
                    System.out.print("Enter the department name to display patients: ");
                    String o = scanner.next();
                    Department department = departmentService.getDepartmentByName(o);

                    if (department != null) {
                        List<Patient> patientsByDepartment = patientService.getPatientsByDepartment(department);
                        if (!patientsByDepartment.isEmpty()) {
                            System.out.println("Patients in " + o + " Department:");
                            for (Patient patient : patientsByDepartment) {
                                System.out.println("Full Name: " + patient.getFullName());
                                System.out.println("Age: " + patient.getAge());
                                System.out.println("Gender: " + patient.getGender());
                                System.out.println();
                            }
                        } else {
                            System.out.println("No patients found in " + o + " Department.");
                        }
                    } else {
                        System.out.println("Department not found.");
                    }
                    break;

            }
        } while (choice != 0);
    }
}