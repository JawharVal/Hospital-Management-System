package org.example.Services;

import org.example.DIAnnotations.Component;
import org.example.models.Department;

import java.util.ArrayList;
import java.util.List;

@Component
public class DepartmentService {

    private final List<Department> departments = new ArrayList<>();


    public Department createDepartment(String name) {
        Department department = new Department();
        department.setName(name);
        departments.add(department);
        return department;
    }

    public void deleteDepartment(Department department) {
        departments.remove(department);
    }

    public void updateDepartment(Department department, String newName) {
        if (department != null) {
            department.setName(newName);
        } else {
            System.out.println("Department not found.");
        }
    }


    public Department getDepartmentByName(String name) {
        return departments.stream()
                .filter(d -> d.getName().equals(name))
                .findFirst()
                .orElse(null);
    }

    public List<Department> getAllDepartments() {
        return departments;
    }

}