package org.example.Services;

import org.example.DIAnnotations.Component;
import org.example.models.Department;
import org.example.models.Patient;

import java.util.ArrayList;
import java.util.List;

@Component
public class PatientService {
    private final List<Patient> patients = new ArrayList<>();

    public Patient createPatient(String fullName, int age, String gender, Department department) {
        Patient patient = new Patient();
        patient.setFullName(fullName);
        patient.setAge(age);
        patient.setGender(gender);
        patient.setDepartment(department);
        patients.add(patient);
        department.incrementPatients();
        return patient;
    }

    public void deletePatient(Patient patient) {
        if (patients.remove(patient)) {
            patient.getDepartment().decrementPatients();
        }
    }

    public void updatePatient(Patient patient, String newFullName, int newAge, String newGender) {
        if (patients.contains(patient)) {
            patient.setFullName(newFullName);
            patient.setAge(newAge);
            patient.setGender(newGender);
        }
    }

    public List<Patient> getPatientsByDepartment(Department department) {
        return patients.stream()
                .filter(p -> p.getDepartment() == department)
                .toList();
    }

    public List<Patient> getAllPatients() {
        return patients;
    }

    public Patient findPatientByName(String fullName) {
        return patients.stream()
                .filter(p -> p.getFullName().equals(fullName))
                .findFirst()
                .orElse(null);
    }
}