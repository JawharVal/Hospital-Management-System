package org.example.models;


import lombok.Data;
import org.example.models.Department;

@Data
public class Patient {
    private String fullName;
    private int age;
    private String gender;
    private Department department;
}